public class StringManipulator{
    public String concatSubstring(String hola, int indexinicial, int indexfianl, String mundo){
        return hola.substring(indexinicial, indexfianl) + mundo;
    }
}