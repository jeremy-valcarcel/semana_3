public class StringManipulator{

    public int getIndexOrNull(String word, String subString){
        word.indexOf(subString);
        return word.indexOf(subString);
    }
}