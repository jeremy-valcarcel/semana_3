
public class StringManipulator {
    public int getIndexOrNull(String str, char letter) {
        return str.indexOf(letter);
    }
}